from record import replay

def run_replay(CONFIG_PATH: str):
    replay.replay_mqtt_messages(CONFIG_PATH) # Times to loop
